$.ajax({
    type: 'POST',
    url: url,
    data: data,
    success: success,
    dataType: dataType
});