package com.lhz.dao;

public interface UsersDao {
}
